<!--
Dear contributors,

Please consider providing an executable test case or an example project.
As Spring has many ways to setup, it is really difficult for us to reproduce the problem just from some snippets.

Thank you very much for your contribution!
-->
